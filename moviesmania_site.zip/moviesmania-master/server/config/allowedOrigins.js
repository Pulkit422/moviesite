const allowedOrigins = [
    'https://moviesmania-api.onrender.com'
]
module.exports=allowedOrigins